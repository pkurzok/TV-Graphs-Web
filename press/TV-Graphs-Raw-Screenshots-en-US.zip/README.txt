TV Graphs — Raw Press Screenshots (English, en-US)
===================================================

Contact: Peter Kurzok <tvgraphs@peterkurzok.de>
Website: https://tvgraphs.peterkurzok.de
App Store: https://apps.apple.com/app/tv-graphs-season-ratings/id6804961357

Unframed, full-resolution PNG captures straight from the device screens:
iPhone, iPad, Mac, Apple TV and Apple Vision Pro. You are welcome to use
them in articles, reviews and other coverage of TV Graphs, including
inside your own device frames.

Data notice
-----------
The series, season and episode data shown comes from The Movie Database
(TMDB). This application uses TMDB and the TMDB APIs but is not
endorsed, certified, or otherwise approved by TMDB.

Raw captures in German, Polish, Italian, Spanish and French are
available on request.
